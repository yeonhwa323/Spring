package org.doit.senti.domain.board;

public class SampleVO {

}
