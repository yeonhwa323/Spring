package org.doit.senti.mapper;

import java.util.List;

import org.doit.senti.domain.user.CartDTO;

public interface OrderMapper {
	
}
