package org.doit.senti.service.board;

public class SampleService {

}
