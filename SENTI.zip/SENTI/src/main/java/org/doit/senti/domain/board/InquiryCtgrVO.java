package org.doit.senti.domain.board;

import java.util.List;

public class InquiryCtgrVO {
	
	private int buyInquiry;
	private String buyInquiryName;
	
	private int generalInquiry;
	private String generalInquiryName;
	
	private int etcInquiry;
	private String etcInquiryName;
	
}
