package org.doit.senti.service.user;

public class SampleService {

}
