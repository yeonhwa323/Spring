package org.doit.senti.domain.user;

public class SampleVO {

}
